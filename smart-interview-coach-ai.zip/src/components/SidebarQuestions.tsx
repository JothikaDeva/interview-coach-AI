import { CheckCircle2, Circle, HelpCircle } from "lucide-react";
import { QuestionEvaluation } from "../types";

interface SidebarQuestionsProps {
  currentIndex: number;
  evaluations: { [key: number]: QuestionEvaluation };
  onQuestionSelect?: (index: number) => void;
  questions: { id: number; text: string; category: string }[];
}

export default function SidebarQuestions({
  currentIndex,
  evaluations,
  onQuestionSelect,
  questions,
}: SidebarQuestionsProps) {
  // Group questions dynamically by category
  // Maintaining stable order: we group them as they appear in the questions array
  const groupedCategories: { name: string; items: { q: typeof questions[0]; index: number }[] }[] = [];
  
  questions.forEach((q, index) => {
    let catGroup = groupedCategories.find((c) => c.name === q.category);
    if (!catGroup) {
      catGroup = { name: q.category, items: [] };
      groupedCategories.push(catGroup);
    }
    catGroup.items.push({ q, index });
  });

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm h-full flex flex-col">
      <div className="mb-4">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-indigo-500" />
          Practice Checklist
        </h3>
        <p className="text-[11px] text-slate-500 mt-1 font-sans">
          {questions.length === 14 
            ? "Strict placement simulator: 14 benchmark questions" 
            : `Custom Practice Route: ${questions.length} selective tasks`
          }
        </p>
      </div>

      <div className="flex-grow overflow-y-auto space-y-4 pr-1 scrollbar-thin max-h-[420px] lg:max-h-none">
        {groupedCategories.map((cat, catIdx) => (
          <div key={catIdx} className="space-y-1.5 animate-fadeIn">
            <div className="text-[10px] font-bold text-indigo-600/80 tracking-wider uppercase px-2 font-mono">
              {cat.name}
            </div>

            <div className="space-y-1">
              {cat.items.map(({ q, index }) => {
                const isCompleted = evaluations[index] !== undefined;
                const isActive = index === currentIndex;
                const evaluation = evaluations[index];
                
                // Calculate average score if completed
                let avgScore = null;
                if (isCompleted && evaluation) {
                  const { grammar, confidence, communication, technicalAccuracy } = evaluation.scores;
                  const divisor = technicalAccuracy !== null ? 4 : 3;
                  const sum = grammar + confidence + communication + (technicalAccuracy || 0);
                  avgScore = Math.round((sum / divisor) * 10) / 10;
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => isCompleted && onQuestionSelect && onQuestionSelect(index)}
                    disabled={!isCompleted && !isActive}
                    className={`w-full text-left flex items-start gap-2.5 p-2 rounded-lg transition-all ${
                      isActive
                        ? "bg-indigo-50 text-indigo-950 border border-indigo-100 ring-1 ring-indigo-500/10 font-medium"
                        : isCompleted
                        ? "bg-emerald-50/40 hover:bg-emerald-50/80 text-slate-700 cursor-pointer"
                        : "opacity-50 text-slate-450 cursor-not-allowed"
                    }`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-50" />
                      ) : isActive ? (
                        <div className="relative flex h-4 w-4 items-center justify-center">
                          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-indigo-400 opacity-75"></span>
                          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-indigo-600"></span>
                        </div>
                      ) : (
                        <div className="w-4 h-4 rounded-full border border-slate-200 bg-slate-50" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center gap-2">
                        <span className="text-[10px] font-bold text-slate-400 font-mono">
                          Q{index + 1}
                        </span>
                        {avgScore !== null && (
                          <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-1 py-0.2 rounded font-mono">
                            {avgScore}/10
                          </span>
                        )}
                      </div>
                      <p className="text-xs truncate text-slate-700 font-sans mt-0.5">
                        {q.text}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-slate-100 text-[10px] text-slate-400 flex justify-between items-center font-mono">
        <span>Progress</span>
        <span>
          {Object.keys(evaluations).length} / {questions.length} Completed
        </span>
      </div>
    </div>
  );
}
