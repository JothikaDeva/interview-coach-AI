import React, { useState, useMemo } from "react";
import { User, Briefcase, Building2, Sparkles, Award, CheckCircle, ShieldCheck, Search, Sliders, List, CheckSquare, Square, ChevronRight } from "lucide-react";
import { QUESTION_BANK, Question } from "../types";

interface WelcomeScreenProps {
  onStart: (
    name: string,
    role: string,
    company: string,
    isCustomTrack?: boolean,
    customQuestionIds?: number[]
  ) => void;
}

export default function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  // General Session Config
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [company, setCompany] = useState("");
  const [error, setError] = useState("");

  // Track Type: "benchmark" (14 standard Qs) vs "practice" (custom Qs)
  const [track, setTrack] = useState<"benchmark" | "practice">("benchmark");

  // Practice Config
  const [selectionMethod, setSelectionMethod] = useState<"quick" | "manual">("quick");
  const [numQuestions, setNumQuestions] = useState<number>(10);
  const [difficultyFilter, setDifficultyFilter] = useState<"All" | "Easy" | "Medium" | "Hard">("All");
  
  const allCategories = [
    "Technical (Python)",
    "Technical (SQL)",
    "Technical (Data Analytics)",
    "Technical (Excel)",
    "Technical (Power BI)",
    "Behavioral",
    "HR",
    "Situational"
  ];
  const [selectedCategories, setSelectedCategories] = useState<string[]>(allCategories);
  
  // Manual Question Explorer Search/Selection
  const [searchQuery, setSearchQuery] = useState("");
  const [manualCategoryFilter, setManualCategoryFilter] = useState<string>("All");
  const [manuallySelectedIds, setManuallySelectedIds] = useState<number[]>([]);

  // Sample quick selections
  const sampleRoles = ["Software Engineer", "Data Analyst", "Systems Engineer", "Business Analyst", "Product Manager", "HR Consultant"];
  const sampleCompanies = ["Google", "TCS", "Infosys", "Wipro", "Zoho", "Cognizant", "Accenture"];

  // Toggle Category Selection
  const toggleCategory = (cat: string) => {
    setSelectedCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  // Toggle Manual Question Selection
  const toggleManualQuestion = (id: number) => {
    setManuallySelectedIds((prev) =>
      prev.includes(id) ? prev.filter((qid) => qid !== id) : [...prev, id]
    );
  };

  // Filter bank for manual selection
  const filteredQuestionsForBrowsing = useMemo(() => {
    return QUESTION_BANK.filter((q) => {
      const matchesSearch = q.text.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            q.hint.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = manualCategoryFilter === "All" || q.category === manualCategoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, manualCategoryFilter]);

  // Form Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Please enter your name to begin.");
      return;
    }

    let finalQuestionIds: number[] = [];

    if (track === "practice") {
      if (selectionMethod === "quick") {
        // Filter the question bank based on quick filters
        const candidates = QUESTION_BANK.filter((q) => {
          const matchesCategory = selectedCategories.includes(q.category);
          const matchesDifficulty = difficultyFilter === "All" || q.difficulty === difficultyFilter;
          return matchesCategory && matchesDifficulty;
        });

        if (candidates.length === 0) {
          setError("No questions matched your selected filters. Please select different categories or difficulties.");
          return;
        }

        // Shuffle and take up to numQuestions
        const shuffled = [...candidates].sort(() => 0.5 - Math.random());
        finalQuestionIds = shuffled.slice(0, numQuestions).map((q) => q.id);
      } else {
        // Manual Selection Track
        if (manuallySelectedIds.length === 0) {
          setError("Please select at least 1 question from the list to begin practicing.");
          return;
        }
        finalQuestionIds = [...manuallySelectedIds];
      }

      onStart(
        name.trim(),
        role.trim() || "Practice Mode Candidate",
        company.trim() || "Dynamic Placements",
        true, // isCustomTrack = true
        finalQuestionIds
      );
    } else {
      // Standard benchmark mode (14 questions)
      onStart(
        name.trim(),
        role.trim() || "Software Engineer",
        company.trim() || "Campus Placement",
        false
      );
    }
  };

  return (
    <div id="welcome-screen" className="max-w-5xl mx-auto my-6 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-12">
        
        {/* Left Side: Illustration / Welcome Callout */}
        <div className="lg:col-span-4 bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 text-white p-8 flex flex-col justify-between min-h-[500px]">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs text-indigo-200 border border-white/10 mb-6 font-mono">
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              CAMPUS PLACEMENT PREP
            </div>
            <h1 className="text-2xl font-sans font-extrabold tracking-tight mb-4">
              Smart Interview Coach AI
            </h1>
            <p className="text-slate-300 text-xs leading-relaxed mb-6">
              Empowering final-year college students to ace technical, general, behavioral, HR, and situational rounds with custom feedback, placement tips, grammar corrections, and Tamil support.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-1.5 bg-indigo-500/20 rounded text-indigo-300 mt-0.5 shrink-0">
                <Award className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-100">Benchmark Track</p>
                <p className="text-[11px] text-slate-400 leading-normal">Standard 14 questions covering key placement topics in sequence.</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="p-1.5 bg-indigo-500/20 rounded text-indigo-300 mt-0.5 shrink-0">
                <Sliders className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-100">Custom Section Practice</p>
                <p className="text-[11px] text-slate-400 leading-normal">Practice from 80+ expanded questions with custom difficulty settings.</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-1.5 bg-indigo-500/20 rounded text-indigo-300 mt-0.5 shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-100">Quality Diagnostic Center</p>
                <p className="text-[11px] text-slate-400 leading-normal">Use the Dev Test Suite toggled above to dry-run backend AI APIs instantly.</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-4 mt-6 text-[10px] text-slate-400 font-mono text-center">
            Active Database Bank: 80+ Questions
          </div>
        </div>

        {/* Right Side: Setup & Launcher Form */}
        <div className="lg:col-span-8 p-6 md:p-8 flex flex-col justify-between">
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Stage 1: Basic Profiles */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">1. Candidate Profile</h3>
              </div>
              
              <div>
                <label htmlFor="student-name-input" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Your Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4.5 h-4.5" />
                  </div>
                  <input
                    id="student-name-input"
                    type="text"
                    placeholder="e.g. Sundar R"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (error) setError("");
                    }}
                    className="w-full pl-10 pr-4 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors bg-slate-50 font-medium"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="target-role-input" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Target Job Role <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Briefcase className="w-4.5 h-4.5" />
                  </div>
                  <input
                    id="target-role-input"
                    type="text"
                    placeholder="e.g. QA Engineer, Software Dev"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors bg-slate-50 font-medium"
                  />
                </div>
              </div>

              <div className="md:col-span-2">
                <label htmlFor="target-company-input" className="block text-xs font-bold text-slate-600 mb-1.5">
                  Target Company <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Building2 className="w-4.5 h-4.5" />
                  </div>
                  <input
                    id="target-company-input"
                    type="text"
                    placeholder="e.g. Google, TCS, Zoho, Infosys"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors bg-slate-50 font-medium"
                  />
                </div>
              </div>
            </div>

            {/* Stage 2: Interview Track Selection */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">2. Choose Interview Track</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                
                {/* Benchmark Selector */}
                <button
                  type="button"
                  onClick={() => {
                    setTrack("benchmark");
                    setError("");
                  }}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    track === "benchmark"
                      ? "border-indigo-500 bg-indigo-50/40 ring-1 ring-indigo-500/20"
                      : "border-slate-200 hover:border-slate-300 bg-white"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <Award className={`w-5 h-5 ${track === "benchmark" ? "text-indigo-600" : "text-slate-400"}`} />
                    <span className="font-extrabold text-xs text-slate-800">Standard Placement Track</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    A fixed sequence of 14 core benchmark questions covering Self-Intro, Behavioral, Python, SQL, Excel, Power BI, and HR. Highly recommended for complete mock test runs.
                  </p>
                </button>

                {/* Practice Selector */}
                <button
                  type="button"
                  onClick={() => {
                    setTrack("practice");
                    setError("");
                  }}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    track === "practice"
                      ? "border-indigo-500 bg-indigo-50/40 ring-1 ring-indigo-500/20"
                      : "border-slate-200 hover:border-slate-300 bg-white"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <Sliders className={`w-5 h-5 ${track === "practice" ? "text-indigo-600" : "text-slate-400"}`} />
                    <span className="font-extrabold text-xs text-slate-800">Custom Practice Track</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Focus on specific categories, adjust difficulties, or manually pick questions to test from our expanded pool of 80+ professional interview cases.
                  </p>
                </button>

              </div>
            </div>

            {/* Conditional Subpanel: Practice Mode Options */}
            {track === "practice" && (
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-150 space-y-5 animate-fadeIn">
                
                {/* Method selector */}
                <div className="flex gap-4 border-b border-slate-200 pb-2.5 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectionMethod("quick");
                      setError("");
                    }}
                    className={`font-bold transition-all ${
                      selectionMethod === "quick" ? "text-indigo-600 border-b-2 border-indigo-600 pb-2" : "text-slate-500 hover:text-slate-700"
                    }`}
                  >
                    Quick-Build Practice Set
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectionMethod("manual");
                      setError("");
                    }}
                    className={`font-bold transition-all ${
                      selectionMethod === "manual" ? "text-indigo-600 border-b-2 border-indigo-600 pb-2" : "text-slate-500 hover:text-slate-700"
                    }`}
                  >
                    Browse & Pick Questions ({manuallySelectedIds.length})
                  </button>
                </div>

                {/* QUICK SELECTION FILTERS */}
                {selectionMethod === "quick" ? (
                  <div className="space-y-4">
                    {/* Categories Checkboxes */}
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                        Select Categories to Include:
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {allCategories.map((cat) => {
                          const isChecked = selectedCategories.includes(cat);
                          return (
                            <button
                              key={cat}
                              type="button"
                              onClick={() => toggleCategory(cat)}
                              className={`flex items-center gap-2 p-2 rounded-lg text-xs border text-left transition-colors ${
                                isChecked
                                  ? "bg-white border-indigo-200 text-slate-800 font-semibold"
                                  : "bg-transparent border-slate-200 text-slate-400"
                              }`}
                            >
                              <div className="shrink-0">
                                {isChecked ? (
                                  <CheckSquare className="w-4 h-4 text-indigo-600 fill-indigo-50" />
                                ) : (
                                  <Square className="w-4 h-4 text-slate-300" />
                                )}
                              </div>
                              <span className="truncate">{cat}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Difficulty and size */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                          Target Difficulty Level:
                        </label>
                        <select
                          value={difficultyFilter}
                          onChange={(e) => setDifficultyFilter(e.target.value as any)}
                          className="w-full text-xs font-semibold py-2 px-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 bg-white"
                        >
                          <option value="All">All Difficulties (Mixed)</option>
                          <option value="Easy">Easy Level</option>
                          <option value="Medium">Medium Level</option>
                          <option value="Hard">Hard Level</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                          Number of Questions:
                        </label>
                        <select
                          value={numQuestions}
                          onChange={(e) => setNumQuestions(Number(e.target.value))}
                          className="w-full text-xs font-semibold py-2 px-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 bg-white"
                        >
                          <option value={5}>5 Questions (Express Practice)</option>
                          <option value={10}>10 Questions (Standard Practice)</option>
                          <option value={15}>15 Questions (Thorough Practice)</option>
                          <option value={20}>20 Questions (Extended Challenge)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* MANUAL EXPLORER BROWSER */
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Search questions or keyword..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full text-xs pl-9 pr-3 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <select
                        value={manualCategoryFilter}
                        onChange={(e) => setManualCategoryFilter(e.target.value)}
                        className="text-xs font-semibold border border-slate-200 rounded-lg bg-white px-2 focus:outline-none"
                      >
                        <option value="All">All Categories</option>
                        {allCategories.map((cat) => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>

                    {/* Scrollable list */}
                    <div className="border border-slate-200 rounded-xl bg-white max-h-[220px] overflow-y-auto p-2 divide-y divide-slate-100 scrollbar-thin">
                      {filteredQuestionsForBrowsing.length === 0 ? (
                        <p className="text-center text-xs text-slate-400 py-6">No matching questions found in the database.</p>
                      ) : (
                        filteredQuestionsForBrowsing.map((q) => {
                          const isSelected = manuallySelectedIds.includes(q.id);
                          return (
                            <button
                              key={q.id}
                              type="button"
                              onClick={() => toggleManualQuestion(q.id)}
                              className="w-full text-left p-2 hover:bg-slate-50 flex items-start gap-2 text-xs transition-colors"
                            >
                              <div className="mt-0.5 shrink-0">
                                {isSelected ? (
                                  <CheckSquare className="w-4.5 h-4.5 text-indigo-600 fill-indigo-50" />
                                ) : (
                                  <Square className="w-4.5 h-4.5 text-slate-300" />
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-baseline gap-2 mb-0.5">
                                  <span className="text-[9px] font-mono font-bold text-slate-400">{q.category}</span>
                                  <span className={`text-[9px] font-bold px-1 py-0.2 rounded font-mono uppercase ${
                                    q.difficulty === "Easy" ? "text-emerald-700 bg-emerald-50" :
                                    q.difficulty === "Medium" ? "text-amber-700 bg-amber-50" : "text-rose-700 bg-rose-50"
                                  }`}>{q.difficulty}</span>
                                </div>
                                <p className="font-semibold text-slate-700 leading-normal">{q.text}</p>
                              </div>
                            </button>
                          );
                        })
                      )}
                    </div>

                    <div className="flex justify-between items-center text-[11px] text-slate-500 font-mono">
                      <span>Total pool: {filteredQuestionsForBrowsing.length} questions</span>
                      <span className="font-semibold text-indigo-600">{manuallySelectedIds.length} questions selected for practice</span>
                    </div>
                  </div>
                )}

              </div>
            )}

            {/* Error Indicators */}
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium">
                {error}
              </div>
            )}

            {/* Start Button */}
            <div className="pt-2">
              <button
                id="start-session-button"
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl text-xs transition-all shadow-md shadow-indigo-600/10 hover:shadow-indigo-600/20 flex items-center justify-center gap-2"
              >
                <span>Launch Mock Practice Session</span>
                <ChevronRight className="w-4.5 h-4.5" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
