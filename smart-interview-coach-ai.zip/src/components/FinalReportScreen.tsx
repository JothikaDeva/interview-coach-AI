import { useState } from "react";
import { OverallReport, QuestionEvaluation, INTERVIEW_QUESTIONS } from "../types";
import { 
  Award, TrendingUp, Sparkles, CheckCircle, ListTodo, Calendar, 
  RotateCcw, ShieldAlert, ArrowRight, HelpCircle, FileText, ChevronDown, ChevronRight
} from "lucide-react";

interface FinalReportScreenProps {
  studentName: string;
  targetRole: string;
  targetCompany: string;
  evaluations: { [key: number]: QuestionEvaluation };
  report: OverallReport;
  onRestart: () => void;
  onSelectQuestion: (index: number) => void;
}

export default function FinalReportScreen({
  studentName,
  targetRole,
  targetCompany,
  evaluations,
  report,
  onRestart,
  onSelectQuestion
}: FinalReportScreenProps) {
  const [activeDayIdx, setActiveDayIdx] = useState<number>(0);
  const { overallScore, strengths, improvementAreas, sevenDayPlan } = report;

  // Placement readiness evaluation phrase
  const getReadinessVerdict = (score: number) => {
    if (score >= 90) return { title: "Outstanding Candidate", desc: "Superb confidence, accurate tech base, and pristine communication. Highly ready for elite placements!", color: "text-emerald-600 bg-emerald-50 border-emerald-200" };
    if (score >= 80) return { title: "Placement Ready", desc: "Solid presentation with strong communication. Just needs minor tweaks or specific tool polish.", color: "text-indigo-600 bg-indigo-50 border-indigo-200" };
    if (score >= 65) return { title: "Moderate Polish Needed", desc: "Possesses correct core knowledge but needs practice in expressing ideas confidently and fixing minor grammar/vocab errors.", color: "text-amber-600 bg-amber-50 border-amber-200" };
    return { title: "Intense Practice Recommended", desc: "Needs thorough mock simulations. Work heavily on fundamental Python/SQL questions, and follow the 7-day correction routine.", color: "text-rose-600 bg-rose-50 border-rose-200" };
  };

  const verdict = getReadinessVerdict(overallScore);

  return (
    <div id="final-report-screen" className="max-w-5xl mx-auto my-6 space-y-8 p-1">
      {/* Celebration Header */}
      <div className="bg-gradient-to-r from-indigo-950 via-indigo-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-xl border border-indigo-800">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Award className="w-48 h-48 text-indigo-100" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1 bg-indigo-500/20 text-indigo-300 text-xs px-3 py-1 rounded-full border border-indigo-500/20 font-mono">
              <Sparkles className="w-3.5 h-3.5 animate-bounce" />
              MOCK INTERVIEW COMPLETED
            </div>
            <h2 className="text-3xl font-bold tracking-tight">Congratulations, {studentName}!</h2>
            <p className="text-slate-300 text-sm max-w-xl">
              You have successfully powered through all 14 structured campus recruitment questions. Here is your full intelligence report and personalized plan.
            </p>
            <div className="flex flex-wrap gap-4 pt-3 text-xs text-indigo-200 font-mono">
              <span className="bg-white/5 px-2.5 py-1 rounded border border-white/5">Role: <strong className="text-white">{targetRole}</strong></span>
              <span className="bg-white/5 px-2.5 py-1 rounded border border-white/5">Target: <strong className="text-white">{targetCompany}</strong></span>
            </div>
          </div>

          {/* Large Radial Score */}
          <div className="flex flex-col items-center justify-center bg-white/10 rounded-2xl p-6 border border-white/10 min-w-[160px] self-start md:self-auto shadow-inner">
            <span className="text-[10px] uppercase tracking-wider text-indigo-300 font-semibold mb-1">
              Overall Score
            </span>
            <div className="relative flex items-center justify-center">
              <div className="text-4xl font-black font-mono tracking-tight text-white">
                {overallScore}
                <span className="text-xl text-indigo-300 font-normal">/100</span>
              </div>
            </div>
            <span className="text-[10px] text-indigo-200 font-mono mt-2 bg-indigo-500/20 px-2 py-0.5 rounded-full">
              Placement Rating
            </span>
          </div>
        </div>
      </div>

      {/* Placement Readiness Badge */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row gap-3 items-start sm:items-center ${verdict.color}`}>
        <div className="p-2.5 bg-white rounded-lg shadow-sm">
          <TrendingUp className="w-5 h-5 shrink-0" />
        </div>
        <div>
          <h3 className="font-bold text-sm">Placement Verdict: {verdict.title}</h3>
          <p className="text-xs text-slate-600 mt-0.5">{verdict.desc}</p>
        </div>
      </div>

      {/* Strengths and Weaknesses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Key Strengths */}
        <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
            <CheckCircle className="w-4.5 h-4.5 text-emerald-500" />
            Core Placement Strengths
          </h3>
          <ul className="space-y-3">
            {strengths.map((str, idx) => (
              <li key={idx} className="flex gap-3 items-start text-xs text-slate-700 leading-relaxed">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 font-semibold font-mono text-[10px]">
                  {idx + 1}
                </span>
                <span>{str}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Areas for Improvement */}
        <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
            <ShieldAlert className="w-4.5 h-4.5 text-rose-500" />
            Critical Areas for Polish
          </h3>
          <ul className="space-y-3">
            {improvementAreas.map((imp, idx) => (
              <li key={idx} className="flex gap-3 items-start text-xs text-slate-700 leading-relaxed">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-rose-50 text-rose-600 font-semibold font-mono text-[10px]">
                  {idx + 1}
                </span>
                <span>{imp}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 7-Day Placement Improvement Plan */}
      <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-2 pb-3 border-b border-slate-100">
          <Calendar className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-bold text-slate-800">
            Personalized 7-Day Interview Polish Strategy
          </h3>
        </div>
        <p className="text-xs text-slate-500 mb-6">
          Follow this day-by-day regimen designed specifically based on your responses to perfect your placement execution.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Day selectors on Left */}
          <div className="md:col-span-4 space-y-1">
            {sevenDayPlan.map((p, idx) => {
              const isActive = idx === activeDayIdx;
              return (
                <button
                  key={idx}
                  onClick={() => setActiveDayIdx(idx)}
                  className={`w-full text-left p-3 rounded-lg border transition-all flex justify-between items-center ${
                    isActive
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/10"
                      : "bg-slate-50 border-slate-100 hover:bg-slate-100 text-slate-700"
                  }`}
                >
                  <div className="truncate">
                    <span className="text-[10px] font-mono block opacity-80 uppercase tracking-wider">
                      Day {idx + 1}
                    </span>
                    <span className="text-xs font-bold font-sans">{p.day}</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 opacity-70 ${isActive ? "text-white" : "text-slate-400"}`} />
                </button>
              );
            })}
          </div>

          {/* Active Day Details on Right */}
          <div className="md:col-span-8 bg-slate-50/50 rounded-xl p-5 border border-slate-100/50">
            <div className="space-y-4">
              <div>
                <span className="text-[10px] font-bold text-indigo-600 font-mono uppercase tracking-wider block">
                  Actionable Objective:
                </span>
                <h4 className="text-sm font-extrabold text-slate-800 mt-0.5">
                  {sevenDayPlan[activeDayIdx]?.objective}
                </h4>
              </div>

              <div>
                <span className="text-[10px] font-bold text-slate-500 font-mono uppercase tracking-wider block mb-2">
                  Today's Targeted Tasks:
                </span>
                <div className="space-y-2">
                  {sevenDayPlan[activeDayIdx]?.tasks.map((task, tIdx) => (
                    <div
                      key={tIdx}
                      className="bg-white p-3 rounded-lg border border-slate-100 text-xs text-slate-700 flex items-start gap-2.5 shadow-xs"
                    >
                      <input
                        type="checkbox"
                        id={`task-${activeDayIdx}-${tIdx}`}
                        className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500/20"
                      />
                      <label htmlFor={`task-${activeDayIdx}-${tIdx}`} className="leading-relaxed select-none cursor-pointer">
                        {task}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Summary List of Evaluations to Review */}
      <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
          <ListTodo className="w-4.5 h-4.5 text-indigo-500" />
          Review Questions & Feedback Cards
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Click on any completed question below to load its exact coach review, better answers, and scores again:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {INTERVIEW_QUESTIONS.map((q, idx) => {
            const hasEval = evaluations[idx] !== undefined;
            const evalObj = evaluations[idx];

            let avgScore = 0;
            if (evalObj) {
              const { grammar, confidence, communication, technicalAccuracy } = evalObj.scores;
              const divisor = technicalAccuracy !== null ? 4 : 3;
              const sum = grammar + confidence + communication + (technicalAccuracy || 0);
              avgScore = Math.round((sum / divisor) * 10) / 10;
            }

            return (
              <button
                key={q.id}
                onClick={() => hasEval && onSelectQuestion(idx)}
                disabled={!hasEval}
                className={`text-left p-3 rounded-lg border transition-all flex justify-between items-center gap-3 ${
                  hasEval
                    ? "bg-white hover:bg-slate-50 border-slate-100 hover:border-slate-200 cursor-pointer text-slate-700"
                    : "bg-slate-50 border-slate-100 opacity-40 text-slate-400 cursor-not-allowed"
                }`}
              >
                <div className="truncate">
                  <span className="text-[10px] font-mono text-slate-400 block uppercase">
                    Question {q.id} • {q.category}
                  </span>
                  <p className="text-xs font-semibold truncate mt-0.5">
                    {q.text}
                  </p>
                </div>
                {hasEval && (
                  <span className="text-xs font-bold font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded shrink-0">
                    {avgScore}/10
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="flex justify-center pt-4">
        <button
          onClick={onRestart}
          className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-all shadow-md shadow-indigo-600/10 hover:shadow-indigo-600/20"
        >
          <RotateCcw className="w-4 h-4" />
          Start a New Assessment Session
        </button>
      </div>
    </div>
  );
}
