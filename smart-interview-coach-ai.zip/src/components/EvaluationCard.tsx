import { useState } from "react";
import { QuestionEvaluation } from "../types";
import { 
  ThumbsUp, AlertTriangle, Sparkles, Lightbulb, Heart, 
  Globe, Check, Copy, Volume2, ChevronDown, ChevronUp, FileText 
} from "lucide-react";

interface EvaluationCardProps {
  evaluation: QuestionEvaluation;
}

export default function EvaluationCard({ evaluation }: EvaluationCardProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"visual" | "raw">("visual");
  const [isSpeaking, setIsSpeaking] = useState(false);

  const {
    scores,
    strengths,
    areasToImprove,
    betterAnswer,
    interviewTip,
    motivation,
    isTamil,
    tamilFeedback,
    grammarCorrections,
    rawMarkdownText
  } = evaluation;

  const handleCopy = () => {
    navigator.clipboard.writeText(betterAnswer);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const speakText = (text: string) => {
    if ("speechSynthesis" in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    } else {
      alert("Text-to-speech is not supported in this browser.");
    }
  };

  // Convert score value to progress bar color
  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-emerald-600 bg-emerald-50 border-emerald-100";
    if (score >= 6) return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-rose-600 bg-rose-50 border-rose-100";
  };

  const getScoreBarColor = (score: number) => {
    if (score >= 8) return "bg-emerald-500";
    if (score >= 6) return "bg-amber-500";
    return "bg-rose-500";
  };

  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden transition-all duration-300">
      {/* Header and Toggle Tabs */}
      <div className="bg-slate-50 px-5 py-3 border-b border-slate-100 flex justify-between items-center flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-500" />
          <h3 className="font-bold text-sm text-slate-800">Coach Evaluation Card</h3>
        </div>

        <div className="flex bg-slate-200/60 p-0.5 rounded-lg text-xs">
          <button
            onClick={() => setActiveTab("visual")}
            className={`px-3 py-1 rounded-md font-medium transition-all ${
              activeTab === "visual"
                ? "bg-white text-indigo-950 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Visual Dashboard
          </button>
          <button
            onClick={() => setActiveTab("raw")}
            className={`px-3 py-1 rounded-md font-medium transition-all ${
              activeTab === "raw"
                ? "bg-white text-indigo-950 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Raw Log (Required Format)
          </button>
        </div>
      </div>

      {activeTab === "raw" ? (
        <div className="p-5 font-mono text-xs text-slate-800 bg-slate-900/5 overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-[400px]">
          <div className="flex justify-end mb-2">
            <button
              onClick={() => {
                navigator.clipboard.writeText(rawMarkdownText || "");
                alert("Formatted evaluation copied!");
              }}
              className="flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-sans font-medium bg-indigo-600 hover:bg-indigo-700 text-white rounded transition-colors"
            >
              <Copy className="w-3 h-3" /> Copy Raw Text
            </button>
          </div>
          {rawMarkdownText}
        </div>
      ) : (
        <div className="p-5 space-y-6">
          {/* Scores Segment */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
              Performance Metric Breakdown
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "Grammar", score: scores.grammar },
                { label: "Confidence", score: scores.confidence },
                { label: "Communication", score: scores.communication },
                { label: "Technical", score: scores.technicalAccuracy, isTech: true },
              ].map((item, idx) => {
                const showScore = item.score !== null;
                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border flex flex-col justify-between h-20 transition-all ${
                      showScore
                        ? getScoreColor(item.score!)
                        : "text-slate-400 bg-slate-50 border-slate-100"
                    }`}
                  >
                    <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                      {item.label}
                    </span>
                    <div className="flex justify-between items-baseline">
                      <span className="text-lg font-bold font-mono">
                        {showScore ? `${item.score}/10` : "N/A"}
                      </span>
                      {showScore && (
                        <div className="w-8 bg-slate-200/50 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${getScoreBarColor(item.score!)}`}
                            style={{ width: `${item.score! * 10}%` }}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Grammar Corrections Callout (if errors are present) */}
          {grammarCorrections && grammarCorrections.length > 0 && (
            <div className="bg-rose-50/50 border border-rose-100/80 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2 text-rose-800">
                <AlertTriangle className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  Grammar & Syntax Adjustments ({grammarCorrections.length})
                </h4>
              </div>
              <p className="text-[11px] text-rose-700/80 mb-3">
                Polished corrections to make your pitch appropriate for placement criteria:
              </p>
              <div className="space-y-3">
                {grammarCorrections.map((corr, cIdx) => (
                  <div key={cIdx} className="bg-white p-3 rounded-lg border border-rose-100 text-xs">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-1.5">
                      <div>
                        <span className="text-[9px] font-bold text-rose-500 uppercase block font-mono">What you answered:</span>
                        <span className="text-rose-800 line-through">"{corr.original}"</span>
                      </div>
                      <div>
                        <span className="text-[9px] font-bold text-emerald-600 uppercase block font-mono">Correction:</span>
                        <span className="text-emerald-800 font-semibold">"{corr.corrected}"</span>
                      </div>
                    </div>
                    <div className="pt-1.5 border-t border-rose-50 text-slate-600 text-[11px]">
                      <span className="font-medium text-slate-700">Explanation:</span> {corr.explanation}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tamil Feedback Callout */}
          {isTamil && tamilFeedback && (
            <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2 text-indigo-900">
                <Globe className="w-4 h-4 text-indigo-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider font-sans">
                  தமிழ் உரை விளக்கம் (Tamil Dialogue Support)
                </h4>
              </div>
              <div className="space-y-3 text-xs leading-relaxed text-slate-700">
                <div className="bg-white p-3 rounded-lg border border-indigo-100/50">
                  <span className="text-[9px] font-bold text-indigo-600 uppercase block font-mono mb-1">
                    Tamil Explanation (தமிழில் பின்னூட்டம்):
                  </span>
                  <p className="text-slate-800">{tamilFeedback.simpleTamilExplanation}</p>
                </div>
                <div className="bg-white p-3 rounded-lg border border-indigo-100/50">
                  <span className="text-[9px] font-bold text-indigo-600 uppercase block font-mono mb-1">
                    Corrected English Pitch (ஆங்கிலத்தில் சரியான விடை):
                  </span>
                  <p className="font-medium text-indigo-950 italic">"{tamilFeedback.englishCorrectedAnswer}"</p>
                </div>
              </div>
            </div>
          )}

          {/* Strengths & Areas to Improve */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Strengths */}
            <div className="bg-emerald-50/20 border border-emerald-100/50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3 text-emerald-800">
                <ThumbsUp className="w-4 h-4 text-emerald-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  ✅ Key Strengths
                </h4>
              </div>
              <ul className="space-y-2 text-xs text-slate-700">
                {strengths.map((str, sIdx) => (
                  <li key={sIdx} className="flex items-start gap-1.5">
                    <span className="text-emerald-500 font-bold shrink-0">•</span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Areas to Improve */}
            <div className="bg-rose-50/20 border border-rose-100/50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3 text-rose-800">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  ❌ Areas to Improve
                </h4>
              </div>
              <ul className="space-y-2 text-xs text-slate-700">
                {areasToImprove.map((area, aIdx) => (
                  <li key={aIdx} className="flex items-start gap-1.5">
                    <span className="text-rose-500 font-bold shrink-0">•</span>
                    <span>{area}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Better Answer Block */}
          <div className="border border-slate-100 rounded-xl overflow-hidden shadow-sm">
            <div className="bg-indigo-950 text-white px-4 py-2.5 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-300" />
                <span className="text-xs font-bold uppercase tracking-wider">
                  ✨ Coach's Model Answer
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => speakText(betterAnswer)}
                  className={`p-1 rounded bg-white/10 hover:bg-white/20 transition-all ${
                    isSpeaking ? "text-rose-300 bg-white/20" : "text-white"
                  }`}
                  title="Read Better Answer aloud"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleCopy}
                  className="p-1 rounded bg-white/10 hover:bg-white/20 text-white transition-all"
                  title="Copy to clipboard"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <div className="p-4 bg-indigo-50/10 text-xs leading-relaxed text-slate-800 font-sans italic">
              "{betterAnswer}"
            </div>
          </div>

          {/* Tips and Motivation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="flex gap-3 items-start bg-amber-50/30 border border-amber-100 rounded-xl p-4">
              <div className="p-2 bg-amber-50 rounded-lg text-amber-600 shrink-0">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-1">
                  💡 Interview Tip
                </h5>
                <p className="text-xs text-slate-600 leading-normal">{interviewTip}</p>
              </div>
            </div>

            <div className="flex gap-3 items-start bg-indigo-50/20 border border-indigo-100 rounded-xl p-4">
              <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600 shrink-0">
                <Heart className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-indigo-800 uppercase tracking-wider mb-1">
                  🌟 Motivation
                </h5>
                <p className="text-xs text-slate-600 leading-normal">{motivation}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
